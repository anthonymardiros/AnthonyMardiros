

//DO NOT TOUCH THIS FILE 



//Its sole purpose is to call on your code, altering the code could 
//compromise the project's testing files

public class Main{
	public static void main(String[] args) {
		//Calls start to game, nothing else should be in here
		Commands.runGame();

	}
}
