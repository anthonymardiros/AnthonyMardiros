package checkpoint2;

//import the needed libraries HINT you will need a scanner 
import java.util.Scanner;
import java.util.Random;


/*
* In Checkpoint 2, we are going to Stub the methods for your game.
* Do not try to make the actual responses, create rooms, objects, etc...
* We will be learning more about objects, arrays, and more throughout the semester
* 
* Once you have complete all the methods in this Class, be sure to test
* them out thoroughly.  Test all of the commands, try them in UPPERCASE,
* LOWERCASE, and MixeDCAse.
*/


/*
* Create a class called:  Commands
* it must be named exactly that
* be sure to add the ending } at the end of this file
*/
public class Commands{

	
	
	
	
/*
* Main Method is used only to initiate your code.  Often times, the main method 
* is only to test your class, but we currently use it as our mechanism to run your program
* DO NOT CHANGE OR ADD TO THIS METHOD
*/
	public static void main(String[] args) {
		//Calls start to game, nothing else should be in here
  
		//DO NOT TOUCH THIS AREA
		runGame();

	}
	
	
	

	
/*
* Method "gameIntro" that is the text for the game intro
* You will populate the string with however your story
* begins
* @return the string that sets the stage for your game
*/
public static String gameIntro(){

	
	return "Welcome to Zork.";
}	
/*
* getFirstWord should pull the first word out of any phrase (1 or more words)
* @param a string that contains the commands from the user
* @return a string that is only the first word with no spaces, returns a blank string if nothing entered
*/
	public static String getFirstWord(String phrase){
	int spaceExists = phrase.indexOf(" ");
		if(spaceExists != -1) {
			phrase = phrase.substring(0, spaceExists);	
		}
		return phrase;
}
/*
* Method named "getRestOfSentence" removes the first word out of any phrase and returns what is left
* @param a string that contains the phrase from the user
* @return a string that is everything after the first word and the space that follows
*         if only 1 word is entered, this returns an empty string ""
*/
public static String getRestOfSentence(String phrase){
	int space = phrase.indexOf(" ");
        while(space != -1){
            String possibility = phrase.substring(space + 1, phrase.length());
            return possibility;
        }
        return "";
}
	
	

/*
* Method named "north" to state that you moved North	
* @return a string that states "You moved North." 	
*/
public static String north(){
	
	return "You moved North.";
}


	
	
	

/*
* Method named "south" to state that you moved South
* @return a string that states "You moved South."
*/	
public static String south(){

	
	return "You moved South.";
}
/*
* Method named "east" to state the you moved East
* @return a string that states "You moved East."
*/	
public static String east(){

return "You moved East.";	
}

/*
* Method named "west" to state the you moved West
* @return a string that states "You moved West."
*/
public static String west(){

	
return "You moved West.";	
}
/* Method named "take" that allows you to take an approved item
* eventually this will only pick up an item that is present in a room 
* where you are present
*  @param takes in a string to determine what object was picked up
*  @return a string that states "You took the {itemName}."
*/	

public static String take(String object){
	
	
	
	return "You took the " + object + ".";
}
/* Method named "drop" that allow you to drop an approved item
* eventually this will go through your inventory and drop the item
*  @param takes in a string to determine what object was dropped
*  @return a string that states "You dropped the {itemName}"
*/	
public static String drop(String itemDropped){
return "You dropped the " + itemDropped + ".";
	
	
	
}
/* Method named "look" to allow you to look around the room
* This will change to the room description eventually
*  @return a string that states "You looked around the room."
*/	

public static String look(){
return "You looked around the room.";	
	
}
/* Method named "inventory" to display the items in your inventory
* This will eventually include the names of the items in our inventory
*  @return a string that says "The current items in your inventory are: "
*/	
public static String inventory(){
return "The current items in your inventory are: ";
	
	
	
}
/* Method named "examine" that returns the description on an item in your inventory
*  eventually this will give a description of the item
*  @param takes in a string to determine what item you want the description of
*  @return a string that says "Description of {itemName}."
*/	

public static String examine(String objectExamined){
	
return "Description of " + objectExamined + ".";
	
}

/* Method named "eat" that allows you to eat an item it
*  it will eventually remove it from your inventory, but not drop it in the room
*  if you add health, you would update that here
*  @param takes in a string to determine what item you want to eat
*  @return a string that states "You ate the {itemName}."
*/	

public static String eat(String food){
	
return "You ate the " + food + ".";
	
	
}
/* Method named "use" that allows you to use an item it
*  it will eventually trigger an event when used in the proper room only
*  The room trigger will be implemented later
*  @param takes in a string to determine what item you want to use
*  @return a string that says "You used the {itemName}."
*/	

public static String use(String used){
return "You used the " + used + ".";	
	
}
	
/*Method named "help" that returns all of the commands and what they do
*  refer to student handout for required methods: hint they are stubbed in this file
* 	@return the all the command names, an example of it being used, and a description of what they do
*/

public static String help(){
return "Command - Example - Response:\n"
+"north - north - Move North.\n"
+ "south - south - Move South.\n"
+ "east - east - Move East.\n"
+ "west - west - Move West.\n"
+ "look - look - Look around the room.\n"
+ "take - take - Take an object.\n"
+ "drop - drop - Leave an object.\n"
+ "inventory - inventory - Access your inventory.\n"
+ "examine - examine - Examine an item.\n"
+ "eat - eat - Eat an item.\n"
+ "use - use - Use an item.\n"
+ "quit - quit - Quit the game.\n"
+ "Help";

		
		
}
/*Method named "quit" that allows states you have quit your game
* 	@return a message that says "You have decided to quit the game."
*/
public static String quit(){
return "You have decided to quit the game.";

	
	
}
/*Method named "invalid" that produces the invalid response
* 	@return a message thats says "I do not understand."
*/
public static String invalid(){
	return "I do not understand.";
	
	
}
/*
* This method "executeCommand" uses the first word to determine the appropriate method
* to call.  It is just meant to pass the work to the proper method
* @param  it needs the String command and the String item
* @return a String passed back from a method called inside this method 
*/
public static String executeCommand(String command, String item){	
		if(command.equalsIgnoreCase("quit")) {
				return quit();
			} else if(command.equalsIgnoreCase("north")) {
				return north();
			} else if(command.equalsIgnoreCase("south")) {
				return south();
			} else if(command.equalsIgnoreCase("east")) {
				return east();
			} else if(command.equalsIgnoreCase("west")) {
				return west();
			} else if(command.equalsIgnoreCase("drop")) {
				return drop(item);
			} else if(command.equalsIgnoreCase("take")) {
				return take(item);
			} else if(command.equalsIgnoreCase("help")) {
				return help();
			} else if(command.equalsIgnoreCase("examine")) {
				return examine(item);
			} else if(command.equalsIgnoreCase("inventory")) {
				return inventory();
			} else if(command.equalsIgnoreCase("look")) {
				return look();
			} else if(command.equalsIgnoreCase("use")) {
				return use(item);
			} else if(command.equalsIgnoreCase("eat")) {
				return eat(item);
			} else {
				return invalid();
			}				
}
		
	
/*
* Create a method called "runGame"
* This method officially runs your game.  We don't put this in the main method
* because we will learn later that we want to be able to reference it from other
* classes.  there are no parameters or return variables for this method and 
* the name must match the one in the main method.	
*  
* This method must: 
*    repeatedly get an input from the user  
*    break up the input utilizing the methods from above (abstraction)
*    pass the user input to the appropriate method from above
*    stop the game from running when "quit" is entered
*/
public static void runGame(){
        System.out.println(gameIntro());
	Scanner scan = new Scanner(System.in);
	String userInput = "";
	while(!userInput.equalsIgnoreCase("quit")){
                System.out.println("What would you like to do?");
		userInput = scan.nextLine();
		String command = getFirstWord(userInput).toLowerCase();
		String item = getRestOfSentence(userInput).toLowerCase();
		System.out.println(executeCommand(command, item));
	}
	System.out.println("Game Over!");
}

	

}

