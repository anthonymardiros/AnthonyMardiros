package checkpoint2;



/*
 * DO NOT MAKE CHANGES TO THIS FILE
 * 
 * THIS FILE WILL TEST YOUR CODE SO THAT YOU CAN COUNT THE NUMBER OF ERRORS
 * OR CORRECT RESPONSES
 */
public class CommandsTester {

	public static int correct = 0;
	public static int incorrect = 0;
	public static Commands cs = new Commands();


	public static void main(String[] args) {
		testNorth();
		testSouth();
		testEast();
		testWest();
		testLook();
		testTake();
		testDrop();
		testInventory();	
		testExamine();
		testEat();
		testUse();
		testHelp();
		testQuit();
		testInvalid();
		testGetFirstWord();
		testGetRestOfSentence();
		System.out.println("");
		System.out.println("Out of 16 expected methods "+correct+" worked and "+incorrect+ " failed.");
		System.out.println(16-correct-incorrect + " methods ran, but did not produce the expected output.");
		System.out.println("");
		System.out.println("Correct methods need no changes");
		System.out.println("Incorrect methods do not run properly");
		System.out.println("Methods that run, but have an unexpected output likely only need you to update the response text.");
		System.out.println("");
		System.out.println("Finally note that not all functionality is tested with this code, but it does test a "
				+ "significant amount of the assignment.");


	}


	public static void testSouth(){
		try{
			if (Commands.south().contains("outh") && Commands.south().contains("move")){
				correct++;
				System.out.println("Your \"South\" command worked correctly. "
						+ "Number of successful commands " + correct);
			} else {
				
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"South\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testNorth(){
		try{
			if (Commands.north().contains("orth") && Commands.north().contains("move")){
				correct++;
				System.out.println("Your \"North\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"North\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testEast(){
		try{
			if (Commands.east().contains("ast") && Commands.east().contains("move")){
				correct++;
				System.out.println("Your \"East\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"East\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testWest(){
		try{
			if (Commands.west().contains("est") && Commands.west().contains("est")){
				correct++;
				System.out.println("Your \"West\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"West\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testLook(){
		try{
			if (Commands.look().contains("look")){
				correct++;
				System.out.println("Your \"Look\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Look\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testTake(){
		try{
			if ((Commands.take("bell").contains("take")||Commands.take("bell").contains("took"))&&Commands.take("bell").contains("bell")){
				correct++;
				System.out.println("Your \"Take\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Take\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testDrop(){
		try{
			if (Commands.drop("apple").contains("drop")&&Commands.drop("apple").contains("apple")){
				correct++;
				System.out.println("Your \"Drop\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Drop\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testInventory(){
		try{
			if (Commands.inventory().contains("inventory")){
				correct++;
				System.out.println("Your \"Inventory\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Inventory\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testExamine(){
		try{
			if (Commands.examine("bell").contains("bell")){
				correct++;
				System.out.println("Your \"Examine\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Examine\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testEat(){
		try{
			if (Commands.eat("apple").contains("apple")){
				correct++;
				System.out.println("Your \"Eat\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Eat\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testUse(){
		try{
			if (Commands.use("key").contains("key")){
				correct++;
				System.out.println("Your \"Use\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Use\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testHelp(){
		try{
			if (Commands.help().contains("orth")&&Commands.help().contains("outh")&&Commands.help().contains("ast")
					&&Commands.help().contains("est")&&Commands.help().contains("ook")&&Commands.help().contains("ake")
					&&Commands.help().contains("rop")&&Commands.help().contains("ventory")&&Commands.help().contains("xamine")
					&&Commands.help().contains("at")&&Commands.help().contains("se")&&Commands.help().contains("elp")){
				correct++;
				System.out.println("Your \"Help\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Help\" command did not work correctly or is missing commands"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testQuit(){
		try{
			if (Commands.quit().contains("uit")){
				correct++;
				System.out.println("Your \"Quit\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Quit\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testInvalid(){
		try{
			if (Commands.invalid().contains("I do not understand")){
				correct++;
				System.out.println("Your \"Invalid\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"Invalid\" command did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}

	public static void testGetFirstWord(){
		try{
			if (Commands.getFirstWord("apple").contains("apple") && Commands.getFirstWord("apple ball").contains("apple")){
				correct++;
				System.out.println("Your \"getFirstWord\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"getFirstWord\" method did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
	
	public static void testGetRestOfSentence(){
		try{
			if (Commands.getRestOfSentence("apple").equals("") && Commands.getRestOfSentence("ball apple run").contains("apple run")){
				correct++;
				System.out.println("Your \"getRestOfSentence\" command worked correctly. "
						+ "Number of successful commands " + correct);
			}


		} catch (Exception e){
			incorrect++;
			System.out.println("Your \"getRestOfSentence\" method did not work correctly"
					+ "There are "+incorrect+ " errors in your code.");
		}
	}
}
		